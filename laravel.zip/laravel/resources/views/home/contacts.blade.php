@extends('layouts.app')

@section('title','Contacts Page')
@section('content')
  <h1>Contact Page</h1> 
  <p>Contact for more Information</p>   
@endsection