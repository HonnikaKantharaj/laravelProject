@extends('layouts.app')

@section('title','Home Page')
@section('content')
    <h1> Welcome to Laravel Blog </h1>
    <p>Laravel php</p>
@endsection


