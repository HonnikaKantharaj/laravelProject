<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\BlogPost;

class BlogPostFactory extends Factory
{
    protected $model = BlogPost::class;
    public function definition()
    {
        return [
            'title' => $this->$faker->sentence(10),
            'content'=>$this->$faker->paragraphs(3,true)
        ];
    }

    // public function newTitle()
    // {
    //     return $this->state(function (BlogPost $post) {
    //         return [
    //             'title' => 'New title',
    //             'content' => 'Content was changed'
    //         ];
    //     });
    // }
    
    // $factory->state(App\Models\BlogPost::class,'newTitle',function(Faker $faker){

    //     return [
    //         'title' => 'New title',
    //         'content'=>'Content was changed'
    //     ];
    // })

}
