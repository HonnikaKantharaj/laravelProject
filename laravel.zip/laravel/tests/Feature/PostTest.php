<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\BlogPost;
use Tests\TestCase;
use App\Models\Comment;

class PostTest extends TestCase
{
    use RefreshDatabase;
    public function testNoBlogPostWhenNothingInDatabase()
    {
        $response = $this->get('/posts');
        $response->assertSeeText('no posts found');
    }

    public function testSee1BlogPostWhenThereIs1WithNoComments()
    {
        //Arrange
        $post = $this->createDummyBlogPost();

        //Act
        $response = $this->get('/posts');

        //Assert
        $response->assertSeeText('New Title');

        $this->assertDatabaseHas('blog_posts',[
            'title'=>'New Title'
        ]);
    }
    public function testStoreValid()
    {
         $params = [
             'title'=> 'Valid content',
             'content'=> 'At least 10 characters'
         ];

        $this->post('/posts',$params)
        ->assertStatus(302)
        ->assertSessionHas('status');

        $this->assertEquals(session('status'),'blog post was created');
    }

    public function testStoreFail()
    {
         $params = [
             'title'=> 'x',
             'content'=> 'x'
         ];

        $this->post('/posts',$params)
        ->assertStatus(302)
        ->assertSessionHas('errors');
        
        $messages = session('errors')->getMessages();
        //dd($messages);

        $this->assertEquals($messages['title'][0],'The title must be at least 5 characters.');
        $this->assertEquals($messages['content'][0],'The content must be at least 5 characters.');

    }

    public function testUpdateValid()
    {
        //Arrange
        $post = $this->createDummyBlogPost();

        $this->assertDatabaseHas('blog_posts',$post->toArray());

        $params = [
            'title'=> 'A title named new title',
            'content'=> 'Content for the new title'
        ];

       $this->put("/posts/{$post->id}",$params)
       ->assertStatus(302)
       ->assertSessionHas('status');
       
       $this->assertEquals(session('status'),'blog post was Updated');
       $this->assertDatabaseMissing('blog_posts',$post->toArray());
       $this->assertDatabaseHas('blog_posts',[
           'title'=> 'A new named title'
       ]);
       
    }
    public function testDelete()
    {
        $post = $this->createDummyBlogPost();

        $this->put("/posts/{$post->id}")
       ->assertStatus(302)
       ->assertSessionHas('status');

       $this->assertEquals(session('status'),'blog post was deleted');
       $this->assertDatabaseMissing('blog_posts',$post->toArray());
       $this->assertDatabaseHas('blog_posts',[
           'title'=> 'A new named title'
       ]);
    }

    public function testSee1BlogPostWithComment()
    {
        //Arrange
        $post = $this->createDummyBlogPost();
        
        Comment::factory()->count(3)->create([
            'blog_post_id'=> $post->id
        ]);

        $response = $this->get('/posts'); 

        $response -> assertSeeText('3 comments');


    } 

    private function createDummyBlogPost():BlogPost
    {
        // $post= new BlogPost();
        // $post->title= 'New title';
        // $post->content = 'Content was changed';
        // $post->save();
        // return $post;

        return BlogPost::factory()->state('newTitle')->create();
    }
}
