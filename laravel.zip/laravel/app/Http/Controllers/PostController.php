<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePost;
use Illuminate\Http\Request;
use App\Models\BlogPost;

class PostController extends Controller
{
    // private $posts= [
    //     1 => [
    //         'title' => 'Intro to Laravel',
    //         'content' => 'This is a short intro to Laravel',
    //         'is_new' => true,
    //         'has_comments' =>true
    //     ],
    //     2 => [
    //         'title' => 'Intro to PHP',
    //         'content' => 'This is a short intro to PHP',
    //         'is_new' => false
    //     ],
    //     3 => [
    //         'title' => 'Intro to Nodejs',
    //         'content' => 'This is a short intro to Nodejs',
    //         'is_new' => true
    //     ],
    //     4 => [
    //         'title' => 'Intro to GoLang',
    //         'content' => 'This is a short intro to Golang',
    //         'is_new' => false
    //     ]
    // ];
    public function index()
    {
        return view('posts.index',
        ['posts'=> BlogPost::withCount('comments')->get() ]);
    }

    public function create()
    
    {
        return view('posts.create');
    }

    public function store(StorePost $request)
    {
        $validated = $request-> validated();
        $post = new BlogPost();
        $post->title = $validated['title'];
        $post->content = $validated['content'];
        $post->save();

        $request->session()->flash('status','blog post was created');
        return redirect()->route('posts.show',['post'=> $post->id]);
    }                                          //x= "__________" 

    public function show($id)
    {
        //abort_if(!isset($this->posts[id]),404);
        return view('posts.show',[
            'post'=> BlogPost::with('comments')->findOrFail($id)]);
    }

    public function edit($id)
    {
        return view('posts.edit',['post'=> BlogPost::findOrFail($id)]);
    }

    public function update(StorePost $request, $id)
    {
      $post = BlogPost::findOrFail($id); 
      $validated = $request->validated();
      $post -> fill($validated);
      $post->save();
      
      $request->session()->flash('status','blog post was Updated');  
      return redirect()->route('posts.show',['post'=>$post]);

    }

    public function destroy($id)
    {
        $post = BlogPost::findOrFail($id);
        $post->delete();

        session()->flash("status", "blog spot was deleted");
        return redirect()->route('posts.index');

    }
}
