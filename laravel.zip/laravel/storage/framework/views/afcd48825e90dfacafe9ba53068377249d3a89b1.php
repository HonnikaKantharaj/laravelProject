<h3><a href = "<?php echo e(route('posts.show' , ['post' => $post->id])); ?>">
  <?php echo e($post->title); ?></a>
</h3>
      
<div>
  <a href = "<?php echo e(route('posts.edit' , ['post' => $post->id])); ?>"
     class="btn btn-primary">Edit</a>
  <form  class ="d-inline" action="<?php echo e(route('posts.destroy',['post'=> $post->id])); ?>" method = "POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <input type = "submit" value="Delete" class="btn btn-primary">
  </form>  
</div><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/partials/post.blade.php ENDPATH**/ ?>