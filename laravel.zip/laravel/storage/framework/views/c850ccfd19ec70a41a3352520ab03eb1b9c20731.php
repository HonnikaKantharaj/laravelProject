

<?php $__env->startSection('title','Blog Posts'); ?>
<?php $__env->startSection('content'); ?>
  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php echo $__env->make('posts.partials.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php if($post->comments_count): ?>
          <p><?php echo e($post->comments_count); ?> comments</p>
      <?php else: ?>
          <p>No comments yet!</p>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  no posts found
  <?php endif; ?>   
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>