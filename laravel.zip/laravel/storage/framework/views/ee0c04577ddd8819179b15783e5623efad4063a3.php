

<?php $__env->startSection('title','Contacts Page'); ?>
<?php $__env->startSection('content'); ?>
  <h1>Contact Page</h1> 
  <p>Contact for more Information</p>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/home/contacts.blade.php ENDPATH**/ ?>