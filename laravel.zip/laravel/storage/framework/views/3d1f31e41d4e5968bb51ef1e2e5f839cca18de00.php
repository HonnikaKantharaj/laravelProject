

<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
    <h1> Welcome to Laravel Blog </h1>
    <p>Laravel php</p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/home/index.blade.php ENDPATH**/ ?>