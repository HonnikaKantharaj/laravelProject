<div class = "form-group">
  <label for="title">Title</label>
  <input id = "title" type="text" name="title" class = "form-control" 
  value="<?php echo e(old('title', optional($post ?? null)->title)); ?>">
  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class = "alert alert-danger"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class = "form-group">
  <label for = "content">Content</label>
  <textarea class = "form-control" id = "content" name="content" 
  value = <?php echo e(old('content', optional($post ?? null)->content)); ?>></textarea>
</div>

<?php if($errors->any()): ?>
      <div class = " mb-3 ">
        <ul class = "list-group">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class = "list-group-item list-group-item-danger">
                <?php echo e($error); ?>

              </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
  <?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/partials/form.blade.php ENDPATH**/ ?>