

<?php $__env->startSection('title',$post->title); ?>
  <?php $__env->startSection('content'); ?>
 

  <h1><?php echo e($post->title); ?></h1>
  <p><?php echo e($post->content); ?></p>
  <p>Added <?php echo e($post->created_at->diffForHumans()); ?></p>

  <?php if(now()->diffInMinutes($post->created_at) < 5): ?>
      <div class = "alert alert-info"> New! </div>
  <?php endif; ?>
 
  <h4> Comments</h4><br>
    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <p>
        <?php echo e($comment->content); ?>

      </p> 
      <p class = "text-muted">
        added <?php echo e($comment->created_at->diffForHumans()); ?>

      </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No comments yet</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/show.blade.php ENDPATH**/ ?>