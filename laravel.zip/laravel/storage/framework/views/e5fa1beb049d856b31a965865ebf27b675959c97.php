<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src = "<?php echo e(asset('js/app.js')); ?>" defer></script>
  <title>Laravel App- <?php echo $__env->yieldContent('title'); ?></title>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
<body>
  <div class = "d-flex flex-column flex-md-row align-items-center p-3 px-md-4 bg-white border-bottom shadow-sm mb-3">
    <h5 class = "my-0 mr-md-auto font-weight-normal">Laravel App</h5>
    <nav class = "my-2 my-md-0 mr-md-3">
      <a class ="p-2 text-dark" href = "<?php echo e(route('home_index')); ?>">Home</a> 
      <a class ="p-2 text-dark" href = "<?php echo e(route('home_contacts')); ?>">Contacts</a>
      <a class ="p-2 text-dark" href = "<?php echo e(route('posts.index')); ?>">BlogPosts</a>
      <a class ="p-2 text-dark" href = "<?php echo e(route('posts.create')); ?>">Add a blogpost</a>
    </nav>
  </div>
  <div class="container"> 
    <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>