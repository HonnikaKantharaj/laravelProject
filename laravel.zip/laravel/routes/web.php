<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view("home.index");
// });

// Route::get('/contacts', function () {
//     return view("home.contacts");
// });

Route::get('/',[HomeController::class,'home'])->name('home_index');
Route::get('/contacts',[HomeController::class,'contacts'])->name('home_contacts');
Route::get('/single',AboutController::class);


Route::get('/post/1', function () {
    return "Blog Post 1";
})->name('blog_post1');

Route::get('/post/2', function () {
    return "Blog Post 2";
})->name('blog_post2');

Route::get('/recent-posts/{days_ago?}', function ($daysAgo = 20) {
    return 'Recent Posts from ' . $daysAgo . ' days back';
})->name('recent posts');

$posts= [
    1 => [
        'title' => 'Intro to Laravel',
        'content' => 'This is a short intro to Laravel',
        'is_new' => true,
        'has_comments' =>true
    ],
    2 => [
        'title' => 'Intro to PHP',
        'content' => 'This is a short intro to PHP',
        'is_new' => false
    ],
    3 => [
        'title' => 'Intro to Nodejs',
        'content' => 'This is a short intro to Nodejs',
        'is_new' => true
    ],
    4 => [
        'title' => 'Intro to GoLang',
        'content' => 'This is a short intro to Golang',
        'is_new' => false
    ]
];
    

Route::resource('/posts',PostController::class);
//->only(['index','show','create','store','edit','update']);


// Route::get('/posts', function(Request $request) use($posts){  
    //     //dd(request()->all());
    //     dd((int)request()->input('page',1));
    // return view('posts.index',['posts'=> $posts]);  
    // });

// Route::get('/posts/{id}', function($id) {
//     $posts = [
//         1 => [
//             'title' => 'Intro to Laravel',
//             'content' => 'This is a short intro to Laravel',
//             'is_new' => true,
//             'has_comments' =>true
//         ],
//         2 => [
//             'title' => 'Intro to PHP',
//             'content' => 'This is a short intro to PHP',
//             'is_new' => false
//         ]
//     ];

//     return view('posts.show',['post' => $posts[$id]]);
    
// })->name('posts.show');


// Route::prefix('/fun')->name('fun.')->group(function() use($posts){
//     Route::get('/responses',function() use($posts){
//         return response($posts,201)
//         ->header('Content-Type','application.json')
//         ->cookie('MY_COOKIE','Honnika Kantharaj',3600);
//     })->name('response_sent');
    
//     Route::get('/redirect',function(){
//      return redirect('contacts');
//     })->name('redirect_view');

//     Route::get('/back',function(){
//         return back();
//        })->name('back');
    
//     Route::get('/away',function(){
//         return redirect()->away('https://google.com');
//        })->name('away');

//     Route::get('/named-route',function(){
//         return redirect()->route('posts.show',['id'=>1]);
//        })->name('named_route');
    
//     Route::get('/json',function() use($posts){
//         return response()->json($posts);
//        })->name('json');
    
//     Route::get('/download',function() use($posts){
//         return response()->download(public_path('/image.jpeg'),'intro.jpeg');
//     })->name('download');
// });
